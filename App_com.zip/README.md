# App_com

Proyecto creado con **Vite + React**.

## 🚀 Scripts

- `npm install` — Instala dependencias
- `npm run dev` — Inicia el servidor de desarrollo
- `npm run build` — Compila para producción
- `npm run preview` — Previsualiza la app compilada

## 🧱 Estructura
- **src/components** → componentes de React
- **assets** → imágenes y recursos
- **public** → archivos estáticos

## 🪄 Autor
Creado con ❤️ en Visual Studio Code
