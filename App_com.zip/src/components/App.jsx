import React from "react";
import "./App.css";
import Contador from "./Contador";
import Props from "./Props";
import Uno from "./Uno";

function App() {
  return (
    <div className="app">
      <h1>Bienvenido a App_com 🚀</h1>
      <Contador />
      <Props mensaje="Hola desde Props.jsx" />
      <Uno />
    </div>
  );
}

export default App;