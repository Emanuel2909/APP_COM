import React from "react";

function Uno() {
  return <p>Este es el componente Uno.jsx 🎉</p>;
}

export default Uno;