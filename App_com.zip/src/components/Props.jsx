import React from "react";

function Props({ mensaje }) {
  return <p>{mensaje}</p>;
}

export default Props;