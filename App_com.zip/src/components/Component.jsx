import React from "react";

function Component() {
  return <p>Componente genérico listo para usar</p>;
}

export default Component;